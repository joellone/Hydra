#!/bin/bash
ag \
--ignore gmock \
--ignore jedi/ \
--ignore OmniSharpServer \
--ignore testdata \
TODO \
third_party/ycmd/cpp/ycm python autoload plugin
